clc;
clear all;
close all;
% 
 path = '15426'; % 'train'; % 'cityscape'; % 'forest'; % 
 img = imread(['*',path,'.png']);
% %figure,imshow(image),title('img1');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% deal with input image for fusion
% input1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
img1 = simple_color_balance(double(img));%white banlance
lab1 = rgb_to_lab(img1);    %rgb change to lab
% figure,imshow(img1),title('color balance image');
% imwrite(img1, '*.jpg')
% figure,subplot(1,2,1),imshow(img1),title('imupt1 image');
I(:, :, :, 1) = im2double(img1);

% input2
lab2 = lab1;
% bilateralFilter deal with luminance channel
lab2(:, :, 1) = uint8(bilateralFilter(double(lab2(:, :, 1))));
%lab2(:, :, 1) = uint8(guidedfilter(double(rgb2gray(image)),double(lab2(:, :, 1)), 15*4, 10^-6) );

% adaptive histogram equalization
img2 = lab_to_rgb(lab2);

%%%%
imageIn = img2;
sizeIn = size(imageIn);
width = sizeIn(2);
height = sizeIn(1);

imageInComb = zeros(height, width*3);
imageInComb(:, 1:3:end) = imageIn(:, :, 1);
imageInComb(:, 2:3:end) = imageIn(:, :, 2);
imageInComb(:, 3:3:end) = imageIn(:, :, 3);

imageOutComb = adapthisteq(uint8(imageInComb));

imageOut = zeros(height, width, 3);
imageOut(:, :, 1) = imageOutComb(:, 1:3:end);
imageOut(:, :, 2) = imageOutComb(:, 2:3:end);
imageOut(:, :, 3) = imageOutComb(:, 3:3:end);
% subplot(1,2,2),imshow(uint8(imageOut)),title('imupt2 image');
%niqe(uint8(imageOut))

%img2=uint8(imageOut)

% figure,imshow(img2),title('CP-AHE image');
% imwrite(img2, 'C:\Users\������\Desktop\CP-AHE100.jpg')
% I(:, :, :, 2) = im2double(uint8(imageOut));




% lab2(:, :, 1) = adapthisteq(lab2(:, :, 1));
% img2 = lab_to_rgb(lab2);

% subplot(1,2,2),imshow(img2),title('imupt2 image');
% I(:, :, :, 2) = im2double(uint8(img2));

%% FSPD-MEF
%% the finest scale
r1 = 5;
[ D1,i_mean1,aa1,N1] = scale_fine(I,r1);

%% the contrast measure
[w,h,~,~]=size(I);
nlev = floor(log(min(w,h)) / log(2))-3;
D2 = cell(nlev,1);
aa2= cell(nlev,1);
N2= cell(nlev,1);

r2 = 4;
r2_reconstruct = zeros(1,nlev);
for ii=1:nlev
    r2_reconstruct(ii) = r2;
    [ D2{ii},i_mean2,aa2{ii},N2{ii}] = scale_interm(i_mean1,r2);
    i_mean1=i_mean2;
    r2 = max(r2-1,1);
end


%% the coarsest  scale
r3=max(r2-1,1);
[fI3,i_mean3,aa3,N3] = scale_coarse(i_mean2,r3);

%% reconstruct
%% Intermediate layers
for ii = nlev:-1:1
    temp=aa2{ii};
    fI=zeros(size(temp));
    fI(1:2:size(temp,1),1:2:size(temp,2))=fI3;
    B2=boxfilter(fI, r2_reconstruct(ii))./ N2{ii}+D2{ii};
    
    fI3=B2;
end
%% finest layers
fI=zeros(size(aa1));
fI(1:2:size(aa1,1),1:2:size(aa1,2))=B2;
B1=boxfilter(fI, r1)./ N1;
result = repmat(B1,[1 1 3])+D1;



%%
%     figure;
%     imshow(result, []);
%     title('result');
 imwrite(result, '*.png')





function lab = rgb_to_lab(rgb)

cform = makecform('srgb2lab');  %rgb��?lab????
lab = applycform(rgb,cform);    %lab????

end